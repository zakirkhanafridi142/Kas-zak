# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_account
from . import account_bank_statement
from . import account_chart_template
from . import account_fiscal_year
from . import account_journal_dashboard
from . import account_move
from . import account_payment
from . import account_reconcile_model
from . import account_reconcile_model_line
from . import digest
from . import res_config_settings
from . import res_company
from . import bank_rec_widget
from . import bank_rec_widget_line
